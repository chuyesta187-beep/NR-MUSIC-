const path = require("path");

async function main() {
  let botPath = process.env.NR_MUSIC_BOT_FILE || "./examples/index.js";
  botPath = path.resolve(process.cwd(), botPath);

  try {
    require(botPath);
  } catch (err) {
    console.error("NR MUSIC no pudo iniciar.");
    console.error("Archivo:", botPath);
    console.error(err);
    process.exit(1);
  }
}

main();
