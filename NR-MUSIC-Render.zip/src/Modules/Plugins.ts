import { NRMusicPlugin as PlayerMoved } from '../Plugins/PlayerMoved';

export default {
  PlayerMoved,
};
