import { Track } from 'shoukaku';
import { NRMusicTrack } from '../Managers/Supports/NRMusicTrack';

export class NRMusicUtils {
  static convertNRMusicTrackToTrack(track: NRMusicTrack | Track): Track {
    if ((track as Track).info) return track as Track;
    track = track as NRMusicTrack;
    return {
      encoded: track.track,
      info: {
        isSeekable: track.isSeekable,
        isStream: track.isStream,
        title: track.title,
        uri: track.uri,
        identifier: track.identifier,
        sourceName: track.sourceName,
        author: track.author ?? '',
        length: track.length ?? 0,
        position: track.position ?? 0,
      },
      pluginInfo: {},
    };
  }
}
export type Constructor<T> = new (...args: any[]) => T;
