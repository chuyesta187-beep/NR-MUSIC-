import { NRMusicTrack } from './NRMusicTrack';
import { Events, NRMusicError } from '../../Modules/Interfaces';
import { NRMusicPlayer } from '../NRMusicPlayer';

export class NRMusicQueue extends Array<NRMusicTrack> {
  constructor(private readonly nrmusicPlayer: NRMusicPlayer) {
    super();
  }
  /** Get the size of queue */
  public get size() {
    return this.length;
  }

  /** Get the size of queue including current */
  public get totalSize(): number {
    return this.length + (this.current ? 1 : 0);
  }

  /** Check if the queue is empty or not */
  public get isEmpty() {
    return this.length === 0;
  }

  /** Get the queue's duration */
  public get durationLength() {
    return this.reduce((acc, cur) => acc + (cur.length || 0), 0);
  }

  /** Current playing track */
  public current: NRMusicTrack | undefined | null = null;
  /** Previous playing tracks */
  public previous: NRMusicTrack[] = [];

  /**
   * Add track(s) to the queue
   * @param track NRMusicTrack to add
   * @returns NRMusicQueue
   */
  public add(track: NRMusicTrack | NRMusicTrack[]): NRMusicQueue {
    if (!Array.isArray(track)) track = [track];

    if (!this.current) {
      if (Array.isArray(track)) this.current = track.shift();
      else {
        this.current = track;
        return this;
      }
    }

    if (Array.isArray(track)) for (const t of track) this.push(t);
    else this.push(track);
    this.emitChanges();
    return this;
  }

  /**
   * Remove track from the queue
   * @param position Position of the track
   * @returns NRMusicQueue
   */
  public remove(position: number): NRMusicQueue {
    if (position < 0 || position >= this.length)
      throw new NRMusicError(1, 'La posicion debe estar entre 0 y ' + (this.length - 1));
    this.splice(position, 1);
    this.emitChanges();
    return this;
  }

  /** Shuffle the queue */
  public shuffle(): NRMusicQueue {
    for (let i = this.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [this[i], this[j]] = [this[j], this[i]];
    }
    this.emitChanges();
    return this;
  }

  /** Clear the queue */
  public clear(): NRMusicQueue {
    this.splice(0, this.length);
    this.emitChanges();
    return this;
  }

  private emitChanges(): void {
    // @ts-ignore
    this.nrmusicPlayer.shoukaku.emit(Events.QueueUpdate, this.nrmusicPlayer, this);
  }
}
