import { NRMusic } from '../NRMusic';
import { NRMusicQueue } from './Supports/NRMusicQueue';
import {
  FilterOptions,
  Node,
  Player,
  PlayerUpdate,
  TrackExceptionEvent,
  TrackStuckEvent,
  WebSocketClosedEvent,
} from 'shoukaku';
import {
  Events,
  NRMusicError,
  NRMusicPlayerOptions,
  NRMusicSearchOptions,
  NRMusicSearchResult,
  PlayerState,
  PlayOptions,
} from '../Modules/Interfaces';
import { NRMusicTrack } from './Supports/NRMusicTrack';

export class NRMusicPlayer {
  /**
   * NRMusic options
   */
  private options: NRMusicPlayerOptions;
  /**
   * NRMusic Instance
   */
  public readonly nrmusic: NRMusic;
  /**
   * Shoukaku's Player instance
   */
  public shoukaku: Player;
  /**
   * The guild ID of the player
   */
  public readonly guildId: string;
  /**
   * The voice channel ID of the player
   */
  public voiceId: string | null;
  /**
   * The text channel ID of the player
   */
  public textId?: string;
  /**
   * Player's queue
   */
  public readonly queue: NRMusicQueue;
  /**
   * Get the current state of the player
   */
  public state: PlayerState = PlayerState.CONNECTING;
  /**
   * Paused state of the player
   */
  public paused: boolean = false;
  /**
   * Whether the player is playing or not
   */
  public playing: boolean = false;
  /**
   * Loop status
   */
  public loop: 'none' | 'queue' | 'track' = 'none';
  /**
   * Search track/s
   */
  public search: (query: string, options?: NRMusicSearchOptions) => Promise<NRMusicSearchResult>;
  /**
   * Player's volume in percentage (default 100%)
   */
  public volume: number = 100;
  /**
   * Player's custom data
   */
  public readonly data: Map<string, any> = new Map();

  /**
   * Initialize the player
   * @param nrmusic NRMusic instance
   * @param player Shoukaku's Player instance
   * @param options NRMusic options
   * @param customData private readonly customData
   */
  constructor(
    nrmusic: NRMusic,
    player: Player,
    options: NRMusicPlayerOptions,
    private readonly customData: unknown,
  ) {
    this.options = options;
    this.nrmusic = nrmusic;
    this.shoukaku = player;
    this.guildId = options.guildId;
    this.voiceId = options.voiceId;
    this.textId = options.textId;
    this.queue = new (this.options.extends?.queue ?? NRMusicQueue)(this);

    if (options.volume !== 100) this.setVolume(options.volume);

    this.search = (typeof this.options.searchWithSameNode === 'boolean' ? this.options.searchWithSameNode : true)
      ? (query: string, opt?: NRMusicSearchOptions) =>
          nrmusic.search.bind(nrmusic)(query, opt ? { ...opt, nodeName: this.shoukaku.node.name } : undefined)
      : nrmusic.search.bind(nrmusic);

    this.shoukaku.on('start', () => {
      this.playing = true;
      this.emit(Events.PlayerStart, this, this.queue.current);
    });

    this.shoukaku.on('end', (data) => {
      // This event emits STOPPED reason when destroying, so return to prevent double emit
      if (this.state === PlayerState.DESTROYING || this.state === PlayerState.DESTROYED)
        return this.emit(Events.Debug, `Player ${this.guildId} destroyed from end event`);

      if (data.reason === 'replaced') return this.emit(Events.PlayerEnd, this);
      if (['loadFailed', 'cleanup'].includes(data.reason)) {
        if (
          this.queue.current &&
          !(this.queue.previous ?? []).find(
            (x) => x.identifier === this.queue.current?.identifier && x.title === this.queue.current?.title,
          )
        )
          this.queue.previous = [this.queue.current].concat(this.queue.previous) ?? [];
        this.emit(Events.PlayerEnd, this, this.queue.current);
        this.queue.current = null;
        this.playing = false;
        if (!this.queue.length) return this.emit(Events.PlayerEmpty, this);
        return this.play();
      }

      if (this.loop === 'track' && this.queue.current) this.queue.unshift(this.queue.current);
      if (this.loop === 'queue' && this.queue.current) this.queue.push(this.queue.current);

      if (
        this.queue.current &&
        !this.queue.previous.find(
          (x) => x.identifier === this.queue.current?.identifier && x.title === this.queue.current?.title,
        )
      )
        this.queue.previous = [this.queue.current].concat(this.queue.previous) ?? [];

      const currentSong = this.queue.current;
      this.emit(Events.PlayerEnd, this, currentSong);
      this.queue.current = null;

      if (!this.queue.length) {
        this.playing = false;
        return this.emit(Events.PlayerEmpty, this);
      }

      return this.play();
    });

    this.shoukaku.on('closed', (data: WebSocketClosedEvent) => {
      this.playing = false;
      this.emit(Events.PlayerClosed, this, data);
    });

    this.shoukaku.on('exception', (data: TrackExceptionEvent) => {
      this.playing = false;
      this.emit(Events.PlayerException, this, data);
    });

    this.shoukaku.on('update', (data: PlayerUpdate) => this.emit(Events.PlayerUpdate, this, data));
    this.shoukaku.on('stuck', (data: TrackStuckEvent) => this.emit(Events.PlayerStuck, this, data));
    this.shoukaku.on('resumed', () => this.emit(Events.PlayerResumed, this));
    // @ts-ignore
    this.shoukaku.on(Events.QueueUpdate, (referencePlayer: NRMusicPlayer, queue: NRMusicQueue) =>
      this.nrmusic.emit(Events.QueueUpdate, referencePlayer, queue),
    );
  }

  // /**
  //  * Get volume
  //  */
  // public get volume(): number {
  //   return this.shoukaku.filters.volume || 1;
  // }

  /**
   * Get player position
   */
  public get position(): number {
    return this.shoukaku.position;
  }

  /**
   * Get filters
   */
  public get filters(): FilterOptions {
    return this.shoukaku.filters;
  }

  private get node(): Node {
    return this.shoukaku.node;
  }

  /**
   * Pause the player
   * @param pause Whether to pause or not
   * @returns NRMusicPlayer
   */
  public pause(pause: boolean): NRMusicPlayer {
    if (typeof pause !== 'boolean') throw new NRMusicError(1, 'pause debe ser un booleano');

    if (this.paused === pause || !this.queue.totalSize) return this;
    this.paused = pause;
    this.playing = !pause;
    this.shoukaku.setPaused(pause);

    return this;
  }

  /**
   * Set text channel
   * @param textId Text channel ID
   * @returns NRMusicPlayer
   */
  public setTextChannel(textId: string): NRMusicPlayer {
    if (this.state === PlayerState.DESTROYED) throw new NRMusicError(1, 'El reproductor ya ha sido destruido');

    this.textId = textId;

    return this;
  }

  /**
   * Set voice channel and move the player to the voice channel
   * @param voiceId Voice channel ID
   * @returns NRMusicPlayer
   */
  public setVoiceChannel(voiceId: string): NRMusicPlayer {
    if (this.state === PlayerState.DESTROYED) throw new NRMusicError(1, 'El reproductor ya ha sido destruido');
    this.state = PlayerState.CONNECTING;

    this.voiceId = voiceId;
    this.nrmusic.NRMusicOptions.send(this.guildId, {
      op: 4,
      d: {
        guild_id: this.guildId,
        channel_id: this.voiceId,
        self_mute: false,
        self_deaf: this.options.deaf,
      },
    });

    this.emit(Events.Debug, `Player ${this.guildId} moved to voice channel ${voiceId}`);

    return this;
  }

  /**
   * Get the previous track from the queue
   * @param remove Whether to remove the track from the previous list or not. Best to set to true if you want to play it
   */
  public getPrevious(remove: boolean = false): NRMusicTrack | undefined {
    if (remove) return this.queue.previous.shift();
    return this.queue.previous[0];
  }

  /**
   * Set loop mode
   * @param [loop] Loop mode
   * @returns NRMusicPlayer
   */
  public setLoop(loop?: 'none' | 'queue' | 'track'): NRMusicPlayer {
    if (loop === undefined) {
      if (this.loop === 'none') this.loop = 'queue';
      else if (this.loop === 'queue') this.loop = 'track';
      else if (this.loop === 'track') this.loop = 'none';
      return this;
    }

    if (loop === 'none' || loop === 'queue' || loop === 'track') {
      this.loop = loop;
      return this;
    }

    throw new NRMusicError(1, "loop debe ser 'none', 'queue', o 'track'");
  }

  /**
   * Play a track
   * @param track Track to play
   * @param options Play options
   * @returns NRMusicPlayer
   */
  public async play(track?: NRMusicTrack, options?: PlayOptions): Promise<NRMusicPlayer> {
    if (this.state === PlayerState.DESTROYED) throw new NRMusicError(1, 'El reproductor ya ha sido destruido');

    if (track && !(track instanceof NRMusicTrack)) throw new NRMusicError(1, 'track debe ser un NRMusicTrack');

    if (!track && !this.queue.totalSize) throw new NRMusicError(1, 'No hay pistas disponibles para reproducir');

    if (!options || typeof options.replaceCurrent !== 'boolean') options = { ...options, replaceCurrent: false };

    if (track) {
      if (!options.replaceCurrent && this.queue.current) this.queue.unshift(this.queue.current);
      this.queue.current = track;
    } else if (!this.queue.current) this.queue.current = this.queue.shift();

    if (!this.queue.current) throw new NRMusicError(1, 'No hay pistas disponibles para reproducir');

    const current = this.queue.current;
    current.setNRMusic(this.nrmusic);

    let errorMessage: string | undefined;

    const resolveResult = await current.resolve({ player: this as NRMusicPlayer }).catch((e) => {
      errorMessage = e.message;
      return null;
    });

    if (!resolveResult) {
      this.emit(Events.PlayerResolveError, this, current, errorMessage);
      this.emit(Events.Debug, `Player ${this.guildId} resolve error: ${errorMessage}`);
      this.queue.current = null;
      this.queue.size ? await this.play() : this.emit(Events.PlayerEmpty, this);
      return this;
    }

    let playOptions = { track: { encoded: current.track, userData: current.requester ?? {} } };
    if (options) playOptions = { ...playOptions, ...options };

    await this.shoukaku.playTrack(playOptions);

    return this;
  }

  /**
   * Skip the current track
   * @returns NRMusicPlayer
   */
  public skip(): NRMusicPlayer {
    if (this.state === PlayerState.DESTROYED) throw new NRMusicError(1, 'El reproductor ya ha sido destruido');

    this.shoukaku.stopTrack();

    return this;
  }

  /**
   * Seek to a position
   * @param position Position in seconds
   * @returns NRMusicPlayer
   */
  public async seek(position: number): Promise<NRMusicPlayer> {
    if (this.state === PlayerState.DESTROYED) throw new NRMusicError(1, 'El reproductor ya ha sido destruido');
    if (!this.queue.current) throw new NRMusicError(1, "El reproductor no tiene pista actual en la cola");
    if (!this.queue.current.isSeekable) throw new NRMusicError(1, "La pista actual no se puede adelantar o atrasar");

    position = Number(position);

    if (isNaN(position)) throw new NRMusicError(1, 'position debe ser un numero');
    if (position < 0 || position > (this.queue.current.length ?? 0))
      position = Math.max(Math.min(position, this.queue.current.length ?? 0), 0);

    this.queue.current.position = position;
    await this.shoukaku.seekTo(position);

    return this;
  }

  /**
   * Set the volume in percentage (default 100%)
   * @param volume Volume
   * @returns NRMusicPlayer
   */
  public async setVolume(volume: number): Promise<NRMusicPlayer> {
    if (this.state === PlayerState.DESTROYED) throw new NRMusicError(1, 'El reproductor ya ha sido destruido');
    if (isNaN(volume)) throw new NRMusicError(1, 'volume debe ser un numero');

    await this.node.rest.updatePlayer({
      guildId: this.guildId,
      playerOptions: {
        volume,
      },
    });

    this.volume = volume;

    return this;
  }

  /**
   * Connect to the voice channel
   * @returns NRMusicPlayer
   */
  public connect(): NRMusicPlayer {
    if (this.state === PlayerState.DESTROYED) throw new NRMusicError(1, 'El reproductor ya ha sido destruido');
    if (this.state === PlayerState.CONNECTED || !!this.voiceId)
      throw new NRMusicError(1, 'El reproductor ya esta conectado');
    this.state = PlayerState.CONNECTING;

    this.nrmusic.NRMusicOptions.send(this.guildId, {
      op: 4,
      d: {
        guild_id: this.guildId,
        channel_id: this.voiceId,
        self_mute: false,
        self_deaf: this.options.deaf,
      },
    });

    this.state = PlayerState.CONNECTED;

    this.emit(Events.Debug, `Player ${this.guildId} connected`);

    return this;
  }

  /**
   * Disconnect from the voice channel
   * @returns NRMusicPlayer
   */
  public disconnect(): NRMusicPlayer {
    if (this.state === PlayerState.DISCONNECTED || !this.voiceId)
      throw new NRMusicError(1, 'El reproductor ya esta desconectado');
    this.state = PlayerState.DISCONNECTING;

    this.pause(true);
    this.nrmusic.NRMusicOptions.send(this.guildId, {
      op: 4,
      d: {
        guild_id: this.guildId,
        channel_id: null,
        self_mute: false,
        self_deaf: false,
      },
    });

    this.voiceId = null;
    this.state = PlayerState.DISCONNECTED;

    this.emit(Events.Debug, `Player disconnected; Guild id: ${this.guildId}`);

    return this;
  }

  /**
   * Destroy the player
   * @returns NRMusicPlayer
   */
  async destroy(): Promise<NRMusicPlayer> {
    if (this.state === PlayerState.DESTROYING || this.state === PlayerState.DESTROYED)
      throw new NRMusicError(1, 'El reproductor ya ha sido destruido');

    this.disconnect();
    this.state = PlayerState.DESTROYING;
    this.shoukaku.clean();
    await this.nrmusic.shoukaku.leaveVoiceChannel(this.guildId);
    await this.shoukaku.destroy();
    this.shoukaku.removeAllListeners();
    this.nrmusic.players.delete(this.guildId);
    this.state = PlayerState.DESTROYED;

    this.emit(Events.PlayerDestroy, this);
    this.emit(Events.Debug, `Player destroyed; Guild id: ${this.guildId}`);

    return this;
  }

  private emit(event: string, ...args: any): void {
    this.nrmusic.emit(event, ...args);
  }
}
