import { NRMusic, Events } from '../Index';
import { NRMusicPlugin as Plugin } from '../Modules/Interfaces';

export class NRMusicPlugin extends Plugin {
  /**
   * NRMusic instance.
   */
  public nrmusic: NRMusic | null = null;

  /**
   * Initialize the plugin.
   * @param client Discord.Client
   */
  constructor(public client: any) {
    super();
  }

  /**
   * Load the plugin.
   * @param nrmusic NRMusic
   */
  public load(nrmusic: NRMusic): void {
    this.nrmusic = nrmusic;
    this.client.on('voiceStateUpdate', this.onVoiceStateUpdate.bind(this));
  }

  /**
   * Unload the plugin.
   */
  public unload(): void {
    this.client.removeListener('voiceStateUpdate', this.onVoiceStateUpdate.bind(this));
    this.nrmusic = null;
  }

  private onVoiceStateUpdate(oldState: any, newState: any): void {
    if (!this.nrmusic || oldState.id !== this.client.user.id) return;

    const newChannelId = newState.channelID || newState.channelId;
    const oldChannelId = oldState.channelID || oldState.channelId;
    const guildId = newState.guild.id;

    const player = this.nrmusic.players.get(guildId);
    if (!player) return;

    let state = 'UNKNOWN';
    if (!oldChannelId && newChannelId) state = 'JOINED';
    else if (oldChannelId && !newChannelId) state = 'LEFT';
    else if (oldChannelId && newChannelId && oldChannelId !== newChannelId) state = 'MOVED';

    if (state === 'UNKNOWN') return;

    this.nrmusic.emit(Events.PlayerMoved, player, state, { oldChannelId, newChannelId });
  }
}
