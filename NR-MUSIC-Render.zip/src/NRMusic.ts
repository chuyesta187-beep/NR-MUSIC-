import { EventEmitter } from 'events';
import {
  CreatePlayerOptions,
  Events,
  NRMusicError,
  NRMusicOptions as NRMusicOptionsOwO,
  NRMusicSearchOptions,
  NRMusicSearchResult,
  PlayerMovedChannels,
  PlayerMovedState,
  SearchResultTypes,
  SourceIDs,
} from './Modules/Interfaces';
import {
  Connection,
  Connector,
  LoadType,
  Node,
  NodeOption,
  Player,
  PlayerUpdate,
  Shoukaku,
  ShoukakuOptions,
  Track,
  TrackExceptionEvent,
  TrackStuckEvent,
  VoiceChannelOptions,
  WebSocketClosedEvent,
  Constants,
} from 'shoukaku';
const { State, VoiceState } = Constants;
type VoiceStateType = (typeof VoiceState)[keyof typeof VoiceState];

import { NRMusicPlayer } from './Managers/NRMusicPlayer';
import { NRMusicTrack } from './Managers/Supports/NRMusicTrack';
import { NRMusicQueue } from './Managers/Supports/NRMusicQueue';

export interface NRMusicEvents {
  /**
   * Emitted when a track is going to play.
   * @event NRMusic#playerStart
   */
  playerStart: [player: NRMusicPlayer, track: NRMusicTrack];

  /**
   * Emitted when an error occured while resolving track.
   * @event NRMusic#playerResolveError
   */
  playerResolveError: [player: NRMusicPlayer, track: NRMusicTrack, message?: string];

  /**
   * Emitted when a player got destroyed.
   * @event NRMusic#playerDestroy
   */
  playerDestroy: [player: NRMusicPlayer];

  /**
   * Emitted when a player created.
   * @event NRMusic#playerCreate
   */
  playerCreate: [player: NRMusicPlayer];

  /**
   * Emitted when a track ended.
   * @event NRMusic#playerEnd
   */
  playerEnd: [player: NRMusicPlayer];

  /**
   * Emitted when a player got empty.
   * @event NRMusic#playerEmpty
   */
  playerEmpty: [player: NRMusicPlayer];

  /**
   * Emitted when a player got closed.
   * @event NRMusic#playerClosed
   */
  playerClosed: [player: NRMusicPlayer, data: WebSocketClosedEvent];

  /**
   * Emitted when a player got stuck.
   * @event NRMusic#playerStuck
   */
  playerStuck: [player: NRMusicPlayer, data: TrackStuckEvent];

  /**
   * Emitted when a player got resumed.
   * @event NRMusic#playerResumed
   */
  playerResumed: [player: NRMusicPlayer];

  /**
   * Emitted only when you use playerMoved plugin and when the bot moved, joined, or left voice channel.
   * @event NRMusic#playerMoved
   */
  playerMoved: [player: NRMusicPlayer, state: PlayerMovedState, channels: PlayerMovedChannels];

  /**
   * Emitted when an exception occured.
   * @event NRMusic#playerException
   */
  playerException: [player: NRMusicPlayer, data: TrackExceptionEvent];

  /**
   * Emitted when a player updated.
   * @event NRMusic#playerUpdate
   */
  playerUpdate: [player: NRMusicPlayer, data: PlayerUpdate];

  /**
   * Emitted for science purpose.
   * @event NRMusic#playerUpdate
   */
  // maybe this should be changed
  // 'playerUpdate': [data: unknown];

  /**
   * Emitted when a queue updated (track added, changed, etc).
   * @event NRMusic#queueUpdate
   */
  queueUpdate: [player: NRMusicPlayer, queue: NRMusicQueue];
}

export declare interface NRMusic {
  on<K extends keyof NRMusicEvents>(event: K, listener: (...args: NRMusicEvents[K]) => void): this;
  once<K extends keyof NRMusicEvents>(event: K, listener: (...args: NRMusicEvents[K]) => void): this;
  off<K extends keyof NRMusicEvents>(event: K, listener: (...args: NRMusicEvents[K]) => void): this;
  emit(event: string | symbol, ...args: any[]): boolean;
}

export class NRMusic extends EventEmitter {
  /** Shoukaku instance */
  public shoukaku: Shoukaku;
  /** NRMusic players */
  public readonly players: Map<string, NRMusicPlayer> = new Map();

  /**
   * Initialize a NRMusic instance.
   * @param NRMusicOptions NRMusicOptions
   * @param connector Connector
   * @param nodes NodeOption[]
   * @param options ShoukakuOptions
   */
  constructor(
    public NRMusicOptions: NRMusicOptionsOwO,
    connector: Connector,
    nodes: NodeOption[],
    options: ShoukakuOptions = {},
  ) {
    super();

    this.shoukaku = new Shoukaku(connector, nodes, options);

    if (this.NRMusicOptions.plugins) {
      for (const [, plugin] of this.NRMusicOptions.plugins.entries()) {
        if (plugin.constructor.name !== 'NRMusicPlugin')
          throw new NRMusicError(1, 'El plugin debe ser una instancia de NRMusicPlugin');
        plugin.load(this);
      }
    }

    this.players = new Map<string, NRMusicPlayer>();
  }

  // Modified version of Shoukaku#joinVoiceChannel
  // Credit to @deivu
  protected async createVoiceConnection(
    newPlayerOptions: VoiceChannelOptions,
    nrmusicPlayerOptions: CreatePlayerOptions,
  ): Promise<Player> {
    if (this.shoukaku.connections.has(newPlayerOptions.guildId) && this.shoukaku.players.has(newPlayerOptions.guildId))
      return this.shoukaku.players.get(newPlayerOptions.guildId)!;
    if (
      this.shoukaku.connections.has(newPlayerOptions.guildId) &&
      !this.shoukaku.players.has(newPlayerOptions.guildId)
    ) {
      this.shoukaku.connections.get(newPlayerOptions.guildId)!.disconnect();
      // tslint:disable-next-line:no-console
      console.log(
        '[NRMusicError; l220 NRMusic.ts] -> Connection exist but player not found. Destroying connection...',
      );
    }

    const connection = new Connection(this.shoukaku, newPlayerOptions);
    this.shoukaku.connections.set(connection.guildId, connection);
    try {
      await connection.connect();
    } catch (error) {
      this.shoukaku.connections.delete(newPlayerOptions.guildId);
      throw error;
    }
    try {
      let node;
      if (nrmusicPlayerOptions.loadBalancer) node = await this.getLeastUsedNode();
      else if (nrmusicPlayerOptions.nodeName)
        node = this.shoukaku.nodes.get(nrmusicPlayerOptions.nodeName) ?? (await this.getLeastUsedNode());
      else node = this.shoukaku.options.nodeResolver(this.shoukaku.nodes);
      if (!node) throw new NRMusicError(3, 'No se encontro ningun nodo');

      const player = this.shoukaku.options.structures.player
        ? new this.shoukaku.options.structures.player(connection.guildId, node)
        : new Player(connection.guildId, node);
      const onUpdate = (state: VoiceStateType) => {
        if (state !== VoiceState.SESSION_READY) return;
        player.sendServerUpdate(connection);
      };
      await player.sendServerUpdate(connection);
      connection.on('connectionUpdate', onUpdate);
      this.shoukaku.players.set(player.guildId, player);
      return player;
    } catch (error) {
      connection.disconnect();
      this.shoukaku.connections.delete(newPlayerOptions.guildId);
      throw error;
    }
  }

  /**
   * Create a player.
   * @param options CreatePlayerOptions
   * @returns Promise<NRMusicPlayer>
   */
  public async createPlayer<T extends NRMusicPlayer>(options: CreatePlayerOptions): Promise<T | NRMusicPlayer> {
    const exist = this.players.get(options.guildId);
    if (exist) return exist;

    let node;
    if (options.loadBalancer) node = this.getLeastUsedNode();
    else if (options.nodeName) node = this.shoukaku.nodes.get(options.nodeName) ?? this.getLeastUsedNode();
    else node = this.shoukaku.options.nodeResolver(this.shoukaku.nodes);

    if (!options.deaf) options.deaf = false;
    if (!options.mute) options.mute = false;

    if (!node) throw new NRMusicError(3, 'No se encontro ningun nodo');

    const shoukakuPlayer = await this.createVoiceConnection(
      {
        guildId: options.guildId as string,
        channelId: options.voiceId as string,
        deaf: options.deaf,
        mute: options.mute,
        shardId: options.shardId && !isNaN(options.shardId) ? options.shardId : 0,
      },
      options,
    );

    const nrmusicPlayer = new (this.NRMusicOptions.extends?.player ?? NRMusicPlayer)(
      this,
      shoukakuPlayer,
      {
        guildId: options.guildId,
        voiceId: options.voiceId,
        textId: options.textId,
        deaf: options.deaf,
        volume: isNaN(Number(options.volume)) ? 100 : (options.volume as number),
      },
      options.data,
    );
    this.players.set(options.guildId, nrmusicPlayer);
    this.emit(Events.PlayerCreate, nrmusicPlayer);
    return nrmusicPlayer;
  }

  /**
   * Get a player by guildId.
   * @param guildId Guild ID
   * @returns NRMusicPlayer | undefined
   */
  public getPlayer<T extends NRMusicPlayer>(guildId: string): (T | NRMusicPlayer) | undefined {
    return this.players.get(guildId);
  }

  /**
   * Destroy a player.
   * @param guildId Guild ID
   * @returns void
   */
  public destroyPlayer<T extends NRMusicPlayer>(guildId: string): void {
    const player = this.getPlayer<T>(guildId);
    if (!player) return;
    player.destroy();
    this.players.delete(guildId);
  }

  /**
   * Get the least used node.
   * @param group The group where you want to get the least used nodes there. Case-sensitive, catch the error when there is no such group
   * @returns Node
   */
  public async getLeastUsedNode(group?: string): Promise<Node> {
    const nodes: Node[] = [...this.shoukaku.nodes.values()];

    const onlineNodes = nodes.filter((node) => node.state === State.CONNECTED && (!group || node.group === group));
    if (!onlineNodes.length && group && !nodes.find((x) => x.group === group))
      throw new NRMusicError(2, `No existe el grupo: ${group}`);
    if (!onlineNodes.length)
      throw new NRMusicError(2, !!group ? `No hay nodos conectados en ${group}` : 'No hay nodos conectados');

    const temp = await Promise.all(
      onlineNodes.map(async (node) => ({
        node,
        players: (await node.rest.getPlayers())
          .filter((x) => this.players.get(x.guildId))
          .map((x) => this.players.get(x.guildId)!)
          .filter((x) => x.shoukaku.node.name === node.name).length,
      })),
    );

    return temp.reduce((a, b) => (a.players < b.players ? a : b)).node;
  }

  /**
   * Search a track by query or uri.
   * @param query Query
   * @param options NRMusicOptions
   * @returns Promise<NRMusicSearchResult>
   */
  public async search(query: string, options?: NRMusicSearchOptions): Promise<NRMusicSearchResult> {
    const node = options?.nodeName
      ? (this.shoukaku.nodes.get(options.nodeName) ?? (await this.getLeastUsedNode()))
      : await this.getLeastUsedNode();
    if (!node) throw new NRMusicError(3, 'No hay nodos disponibles');

    const source = (SourceIDs as any)[
      (options?.engine && ['youtube', 'youtube_music', 'soundcloud'].includes(options.engine)
        ? options.engine
        : null) ||
        (!!this.NRMusicOptions.defaultSearchEngine &&
        ['youtube', 'youtube_music', 'soundcloud'].includes(this.NRMusicOptions.defaultSearchEngine!)
          ? this.NRMusicOptions.defaultSearchEngine
          : null) ||
        'youtube'
    ];

    const isUrl = /^https?:\/\/.*/.test(query);
    const customSource = options?.source ?? this.NRMusicOptions.defaultSource ?? `${source}search:`;

    const result = await node.rest.resolve(!isUrl ? `${customSource}${query}` : query).catch((_) => null);
    if (!result || result.loadType === LoadType.EMPTY) return this.buildSearch(undefined, [], 'SEARCH');

    let loadType: SearchResultTypes;
    let normalizedData: {
      playlistName?: string;
      tracks: Track[];
    } = { tracks: [] };
    switch (result.loadType) {
      case LoadType.TRACK: {
        loadType = 'TRACK';
        normalizedData.tracks = [result.data];
        break;
      }

      case LoadType.PLAYLIST: {
        loadType = 'PLAYLIST';
        normalizedData = {
          playlistName: result.data.info.name,
          tracks: result.data.tracks,
        };
        break;
      }

      case LoadType.SEARCH: {
        loadType = 'SEARCH';
        normalizedData.tracks = result.data;
        break;
      }

      default: {
        loadType = 'SEARCH';
        normalizedData.tracks = [];
        break;
      }
    }
    this.emit(Events.Debug, `Searched ${query}; Track results: ${normalizedData.tracks.length}`);

    return this.buildSearch(
      normalizedData.playlistName ?? undefined,
      normalizedData.tracks.map((track) => new NRMusicTrack(track, options?.requester)),
      loadType,
    );
  }

  private buildSearch(
    playlistName?: string,
    tracks: NRMusicTrack[] = [],
    type?: SearchResultTypes,
  ): NRMusicSearchResult {
    return {
      playlistName,
      tracks,
      type: type ?? 'SEARCH',
    };
  }
}
